import jp.gr.java_conf.mith.kiss.*;
/*

// Kiss on Java 1.1.0 by MITH@mmk
// 0.1.0 by 7/26
// 0.1.1 by 7/28 class����
// 0.2.0 by 7/28 GS Kiss �Ή�
// 0.2.1 by 7/30 ���̃��W���[���ł̕ύX�Ȃ�
// 0.3.0 by 8/1  �O���Z���N�^�p���\�b�h�̒ǉ��iLiveConnect)
// 0.4.0 by 8/2  ���񃍁[�h�ǉ�
// 0.4.1 by 8/10 �O���Z���N�^�p�̃��\�b�h�ǉ��i�O���A�v���b�g�j
// 0.4.2 by 8/16 Clip Loading�iCell�����厞�̍������j
// 0.4.3 by 8/17 reproduceImage�̎d�l�ύX�i�O�̏�Ԃ�ێ��j
//               click�̎d�l�ύX
// 0.5.0 by 9/09 FileLoad���W���[���̕ύX
// 1.1.0a1 by 98/01/28 Zip�Ή����W���[���̑啝�ύX for JDK 1.1
// 1.1.0a2 by 98/01/29 KISS�ˑ����[�`����KissManager�ւ̕���
// 1.1.0a3 by 98/02/01 FKISS�C���v�������g
// JKiss  Kiss On Java Application
*/

/**
 * Kiss on Java Application
 * 
 * usage : java -classpath jkiss.jar;%classpath% JKiss
 *
 * �eButton�̐���
 * open : KISS��cfg�t�@�C�����J���܂��B
 * zip  : zip�A�[�J�C�u���ꂽKISS�t�@�C�����J���܂��B
 * exit : �v���O�����𔲂��܂��B
 * 
 * author  MITH@mmk
 * @version 1.1.0
 * @since JDK 1.1.1
 * @see KissLoader
 */

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.net.*;
import java.io.*;
import java.util.zip.*;
import java.util.*;

public class JKiss extends Frame implements FKissNotify,ActionListener,FilenameFilter,ItemListener {
  private int patternSelect = 0;
  KissCanvas canvas;
  KissManager manager;
  File kissbase;
  FileDialog f;
  private KissControler ctl;
  String zipfile = "";
  Panel p1;
  Choice choice;
  Dialog dialog = null;
  Button b=null;

  void alart(String s[]) {
    dialog = new Dialog(this,"Object :" + s[0],true);
    GridLayout layout;
    Panel p,p0;
    dialog.setLayout(new BorderLayout());
    p0 = new Panel(layout = new GridLayout(0,1,0,0));
    dialog.add(p0,"Center");
    for(int i=1;i<s.length;i++)p0.add(new Label(s[i]));
      dialog.add(p = new Panel(new FlowLayout(FlowLayout.CENTER,0,0)),"South");
      p.add(b = new Button("OK"));
      b.setActionCommand("ALART");
      b.addActionListener(this);

      dialog.pack();

      Toolkit tk = getToolkit();
      Dimension d1 = tk.getScreenSize();
      Dimension d2 = dialog.getSize();
      dialog.setLocation((d1.width-d2.width)/2,(d1.height-d2.height)/2);

      dialog.show();
  }


  public boolean accept(File dir,String name) {
    String ex = name.substring(name.length()-4);
    if(ex.equals(".cnf") || ex.equals(".zip")) {
      return true;
    }
    return false;
  }

  public void itemStateChanged(ItemEvent e) {
    if(choice.getSelectedIndex() == 0)return;
    String name = choice.getSelectedItem();
    if(e.getStateChange() == ItemEvent.SELECTED) {
      try {
        loadKiss(name,true);
      } catch (IOException exception) {
        String s[] = new String [4];
        s[0] = "Load Error!!";
        s[1] = "File Load Failed in ...";
        s[2] = "    " + kissbase + zipfile;
        s[2] = "    Config :" + name;
        alart(s);
      }
    }
  }

  public void actionPerformed(ActionEvent e) {
    if(e.getActionCommand().equals("ALART")) {
      dialog.dispose();
      b.removeActionListener(this);
      dialog = null;
      b = null;
    }
    if(e.getActionCommand().equals("EXIT")) {
      System.exit(0);
    }
    if(e.getActionCommand().equals("INFO")) {
      alart(getInfo());
    }
    if(e.getActionCommand().equals("LOAD")) {
      f.setFile("*.cnf");
      f.show();
      String name = f.getFile();
      if(name==null)return;
      zipfile = "";
      choice.setEnabled(false);
      choice.removeAll();
      kissbase = new File(f.getDirectory());
      try {
        loadKiss(name,false);
      } catch (IOException exception) {
        String s[] = new String [3];
        s[0] = "Load Error!!";
        s[1] = "File Load Failed in ...";
        s[2] = "    " + kissbase + name;
        alart(s);
      }
    }
    if(e.getActionCommand().equals("LOADZIP")) {
      f.setFile("*.zip");
      f.show();
      String name = f.getFile();
      if(name==null)return;
      kissbase = new File(f.getDirectory());

      String cfgfile ="";
      try {
        zipfile = "";
        choice.removeAll();
        ZipFile zip = new ZipFile(new File(kissbase,name));
        Enumeration enum = zip.entries();
        while(enum.hasMoreElements()) {
          ZipEntry entry = (ZipEntry)enum.nextElement();
          String str = entry.getName();
          String ex = str.substring(str.length()-4);
          if(ex.equalsIgnoreCase(".cnf")) {
            choice.addItem(str);
            cfgfile = str;
          }
        }
        if(choice.getItemCount()==1) {
          zipfile = name;
          loadKiss(cfgfile,true);
        }
        if(choice.getItemCount()>1) {
          choice.insert("- Select config -",0);
          choice.setEnabled(true);
          zipfile = name;
        }
      } catch (IOException exception) {
        String s[] = new String [4];
        s[0] = "Load Error!!";
        s[1] = "File Load Failed in ...";
        s[2] = "    " + kissbase + name;
        s[3] = "    Config :" + cfgfile;
        alart(s);
      }
    }
  }

  public String[] getInfo() {
     String s[] = new String [5];
     s[0] = "Kiss On Java 1.1.0 beta2pre";
     s[1] = s[0] + "     1998/02/06";
     s[2] = "                        (C)1996,8 MITH@mmk";
     s[3] = "";
     Runtime runtime = Runtime.getRuntime();
     long free = runtime.freeMemory();
     long total= runtime.totalMemory();
     long mem = total - free;
     s[4] = "Use Memory :"  +  mem  + " byte";
     return s;
  }

  public void fkissNotify(int cmd,Object obj) {
    switch(cmd) {
      case COL:
      case SET:
        if(ctl!=null)ctl.repaint();
      break;
      case SOUND:
//        play(kissbase,(String)obj);
        System.out.println((String)obj);
      break;
    }
  }

  


  synchronized void zipLoad(String zipfile,String cfgfile) throws IOException {
    ZipInputStream zi = new ZipInputStream(new FileInputStream(new File(kissbase,zipfile)));
    manager.loadFromZip(zi,"SJIS");
    manager.setConfig(cfgfile,patternSelect);
  }

  synchronized void load(String cfgfile) throws IOException {
    String fname;
    InputStream in = new FileInputStream(new File(kissbase,cfgfile));
    KissConfig cnf = new KissConfig(cfgfile);
    cnf.load(in,"SJIS");

    for(int i=0;i<cnf.getMaxColorSet();i++) {
      fname =cnf.getPaletteFile(i).toLowerCase();
      in = new FileInputStream(new File(kissbase,fname));
      manager.addObject(fname,in,KissObject.PALETTE);
    }

    for(int i=0;i<cnf.getMaxCellNumber() ;i++) {
      fname =cnf.getCellFilename(i).toLowerCase();
      in = new FileInputStream(new File(kissbase,fname));
      manager.addObject(fname,in,KissObject.CELL);
    }
    manager.setConfig(cnf,patternSelect);
  }

  public void loadKiss(String cfgfile,boolean fromzif) throws IOException {
    if(manager.getLoaded()) {
      manager.terminate();
      manager.init();
    }
    if(fromzif)zipLoad(zipfile,cfgfile);
    else load(cfgfile);
    Dimension d1 = p1.getSize();
    Dimension d2= manager.getSize();
    int w = d2.width ;
    int h = d1.height + d2.height ;

    Toolkit tk = Toolkit.getDefaultToolkit();
    Dimension d = tk.getScreenSize();
    setBounds((d.width-w)/2,(d.height-h)/3,w,h);
    canvas.setSize(d2.width  ,d2.height );
    pack();
//    repaint();
//    p1.repaint();
//    canvas.repaint();
  }
  
  
  private Button createBitmapButton(String str,Toolkit tk) {
    try {
      File f = new File(str + ".gif");
      int flen = (int)f.length();
      byte b[] = new byte [flen];
      FileInputStream in = new FileInputStream(f);
      int remain_read = flen;
      for(int i=0;i<flen;) {
        int len = in.read(b,i,remain_read);
        remain_read -= len;
        i +=len;
      }
      return (Button) new BitmapButton(str,23,23,tk.createImage(b));
    } catch (IOException e){
      return new Button(str);
    }
  }

  public void init() {
      manager = new FKissManager((FKissNotify)this);

      setLayout(new BorderLayout());

      Button b1,b2,b3,b4;
      Toolkit tk = Toolkit.getDefaultToolkit();

      GridBagLayout layout;
      add(p1 = new Panel(layout = new GridBagLayout()),"North");
      GridBagConstraints c = new GridBagConstraints();
      c.fill = GridBagConstraints.NONE;
      c.insets = new Insets(0,0,0,0);
      c.weightx = 1.0;
      b1 = createBitmapButton("open",tk);
      layout.setConstraints(b1,c);
      p1.add(b1);

      b3 = createBitmapButton("zip",tk);
      layout.setConstraints(b3,c);
      p1.add(b3);

      int ipadx = c.ipadx;

      c.weightx = 0;
      c.gridwidth = 3;
      c.ipadx = 100;
      choice = new Choice();
      layout.setConstraints(choice,c);
      choice.setEnabled(false);
      p1.add(choice);

      c.ipadx = ipadx;
      c.weightx = 1.0;
      c.gridwidth = 1;

      b4 = createBitmapButton("info",tk);
      layout.setConstraints(b4,c);
      p1.add(b4);

      b2 = createBitmapButton("exit",tk);
      layout.setConstraints(b2,c);
      p1.add(b2);

      c.weightx = 9.0;
      c.fill = GridBagConstraints.HORIZONTAL;
      c.gridwidth = GridBagConstraints.REMAINDER;
      c.insets = new Insets(0,2,0,2);
      ctl = new KissControler();
      layout.setConstraints(ctl,c);
      p1.add(ctl);


      b1.setActionCommand("LOAD");
      b1.addActionListener(this);
      b2.setActionCommand("EXIT");
      b2.addActionListener(this);
      b3.setActionCommand("LOADZIP");
      b3.addActionListener(this);
      b4.setActionCommand("INFO");
      b4.addActionListener(this);
      
      choice.addItemListener(this);
      
      ctl.setSize(160,32);

      canvas = new KissCanvas(manager);
      add(canvas,"Center");
      ctl.setManager(manager);
      setTitle("JKiss - Kiss on Java 1.1.0");
      
      Dimension d = tk.getScreenSize();
      setBounds((d.width-448)/2,(d.height-352)/3,448,352);
      pack();
      show();
      f = new FileDialog (this,"File Select",FileDialog.LOAD);
      f.setFilenameFilter(this);
  }


  static public void main(String argv[]) {
    JKiss app = new JKiss();
    app.init();
  }
}
