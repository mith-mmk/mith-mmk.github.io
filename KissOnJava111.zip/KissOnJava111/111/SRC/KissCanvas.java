/*
// KissCanvas  MITH@mmk 1998/02/01
// Kiss�̉�ʕ\�����s���N���X
*/

import jp.gr.java_conf.mith.kiss.*;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class KissCanvas extends Canvas implements ActionListener {
  private KissManager manager = null;
  Frame frame = null;
  Button b=null;

  public void actionPerformed(ActionEvent e) {
    if(e.getActionCommand().equals("OK")) {
      frame.dispose();
      b.removeActionListener(this);
      frame = null;
      b = null;
    }
  }

  public KissCanvas(boolean flag) {
    enableEvents(AWTEvent.MOUSE_MOTION_EVENT_MASK|AWTEvent.MOUSE_EVENT_MASK);
    if(flag)manager = new KissManager(this);
  }

  public KissCanvas() {
    this(false);
  }

  public KissCanvas(KissManager m) {
    this(false);
    setKissManager(m);
  }

  public void setKissManager(KissManager m) {
    manager = m;
    manager.setComponent(this);
  }

  public KissManager getKissManager() {
    return manager;
  }

  public synchronized int getSelectPattern() {
    if(manager==null)return -1;
    return manager.getSelectPattern();
  }

  public synchronized int getSelectPalette() {
    if(manager==null)return -1;
    return manager.getSelectPalette();
  }

  public synchronized void setSelectPattern(int num) {
    if(manager==null)return;
    manager.setSelectPattern (num);
  }

  public synchronized void setSelectPalette(int num) {
    if(manager==null)return;
    manager.setSelectPalette (num);
  }


  public void update(Graphics g) {
    paint(g);
  }

  public void paint (Graphics g) {
    if(manager!=null)manager.paint(g);
    else super.paint(g);
  }

  protected void processMouseEvent(MouseEvent e) {
    int x = e.getX();
    int y = e.getY();
    int m = e.getModifiers();
    if(manager==null)return;

    if(e.isMetaDown()){
      if(e.getID() == MouseEvent.MOUSE_PRESSED)
        if(manager!=null) {
          String s[] = manager.getCommentForXY(x,y);
          if(s!=null && frame ==null) {
            frame = new Frame("Object :" + s[0]);
            GridLayout layout;
            Panel p,p0;
            frame.setLayout(new BorderLayout());
            p0 = new Panel(layout = new GridLayout(0,1,0,0));
            frame.add(p0,"Center");
            for(int i=1;i<s.length;i++)p0.add(new Label(s[i]));
            frame.add(p = new Panel(new FlowLayout(FlowLayout.CENTER,0,0)),"South");
            p.add(b = new Button("OK"));
            b.addActionListener(this);

            frame.pack();

            Toolkit tk = getToolkit();
            Dimension d1 = tk.getScreenSize();
            Dimension d2 = frame.getSize();
            frame.setLocation((d1.width-d2.width)/2,(d1.height-d2.height)/2);

            frame.show();
          }
        }
    } else {
      switch(e.getID()) {
        case MouseEvent.MOUSE_PRESSED:
          manager.press(x,y);
        break;
        case MouseEvent.MOUSE_RELEASED:
          if(manager!=null)manager.release(x,y);
        break;
      }
    }
//    super.processMouseEvent(e);
  }

  protected void processMouseMotionEvent(MouseEvent e) {
    int x = e.getX();
    int y = e.getY();
    int m = e.getModifiers();
    if(e.isMetaDown()) {
      return ;
    }
    switch(e.getID()) {
      case MouseEvent.MOUSE_DRAGGED:
        if(manager!=null)manager.drag(x,y);
      break;
/*
      case MouseEvent.MOUSE_MOVED:
        moved(x,y);
      break;
*/
    }
//    super.processMouseMotionEvent(e);
  }

  void moved(int x,int y) {
    String str;
    str = "X:" + x + "Y:" + y;
    if(manager!=null)manager.putStatus(str); 
  }

  public Dimension getMinimumSize() {
    if(manager == null)return new Dimension(448,320);
    return manager.getSize();
  }

  public Dimension getPreferredSize() {
    if(manager == null)return new Dimension(448,320);
    return manager.getSize();
  }


}
