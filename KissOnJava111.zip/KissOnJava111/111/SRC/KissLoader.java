import jp.gr.java_conf.mith.kiss.*;

// Kiss on Java 1.1.0 by MITH@mmk
// 0.1.0 by 7/26
// 0.1.1 by 7/28 class����
// 0.2.0 by 7/28 GS Kiss �Ή�
// 0.2.1 by 7/30 ���̃��W���[���ł̕ύX�Ȃ�
// 0.3.0 by 8/1  �O���Z���N�^�p���\�b�h�̒ǉ��iLiveConnect)
// 0.4.0 by 8/2  ���񃍁[�h�ǉ�
// 0.4.1 by 8/10 �O���Z���N�^�p�̃��\�b�h�ǉ��i�O���A�v���b�g�j
// 0.4.2 by 8/16 Clip Loading�iCell�����厞�̍������j
// 0.4.3 by 8/17 reproduceImage�̎d�l�ύX�i�O�̏�Ԃ�ێ��j
//               click�̎d�l�ύX
// 0.5.0 by 9/09 FileLoad���W���[���̕ύX
// 1.1.0a1 by 98/01/28 Zip�Ή����W���[���̑啝�ύX for JDK 1.1
// 1.1.0a2 by 98/01/29 KISS�ˑ����[�`����KissManager�ւ̕���
// 1.1.0a3 by 98/02/01 FKISS�C���v�������g

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.applet.*;
import java.net.*;
import java.io.*;
import java.util.zip.*;
import java.util.*;

public class KissLoader extends Applet implements FKissNotify {
  private int patternSelect = 0;

  KissManager manager;
  URL kissbase;

  private boolean isApplet = true;

  public String getAppletInfo() {
     return "Kiss On Java 1.1.0 -beta2pre 1998/02/04 Copyright (C)1996,8  MITH@mmk";
  }

  private KissControler ctl;
  String zipfile = null;
  String cfgfile = null;
  public void fkissNotify(int cmd,Object obj) {
    switch(cmd) {
      case COL:
      case SET:
        if(ctl!=null)ctl.repaint();
      break;
      case SOUND:
        play(kissbase,(String)obj);
        System.out.println((String)obj);
      break;
    }
  }

  public String[][] getParameterInfo() {
     String pinfo[][] =
     {
      {"cfgpath" , "String" ,"Kiss Config & cel files directory "},
      {"zipfile" , "String" ,"Kiss ziparchive"},
      {"cfgname" , "String" ,"Kiss Config file def='kiss.cnf'"},
      {"pattern" , "0-9" ,"Kiss Pattern "},
     };
     return pinfo;
  }


  synchronized void zipLoad(String zipfile,String cfgfile) throws IOException {
    ZipInputStream zi = new ZipInputStream(new URL(kissbase,zipfile).openStream());
    manager.loadFromZip(zi,"SJIS");
    manager.setConfig(cfgfile,patternSelect);
  }

  synchronized void load(String cfgfile) throws IOException {
    String fname;
    InputStream in = (new URL(kissbase,cfgfile).openStream());
    KissConfig cnf = new KissConfig(cfgfile);
    cnf.load(in,"SJIS");

    for(int i=0;i<cnf.getMaxColorSet();i++) {
      fname =cnf.getPaletteFile(i).toLowerCase();
      in = (new URL(kissbase,fname).openStream());
      manager.addObject(fname,in,KissObject.PALETTE);
    }

    for(int i=0;i<cnf.getMaxCellNumber();i++) {
      fname =cnf.getCellFilename(i).toLowerCase();
      in = (new URL(kissbase,fname).openStream());
      manager.addObject(fname,in,KissObject.CELL);
    }
    manager.setConfig(cnf,patternSelect);
  }

  public void getParameters() throws IOException {
    String cfgpath;
  
    zipfile = getParameter("zipfile");
    cfgfile = getParameter("cfgfile");
    if(cfgfile == null )cfgfile="kiss.cnf";
    String tmp = getParameter("pattern");
    if(tmp == null )patternSelect = 0;
    else            patternSelect = Integer.parseInt(tmp);
    cfgpath = getParameter("cfgpath");
    if(cfgpath == null ) {
      kissbase = getCodeBase();
    } else {
      kissbase = new URL(getCodeBase(),cfgpath + "/");
    }
    System.out.println(kissbase);
  }

  public void init() {
    Image gimg = getImage(getCodeBase(),"title.jpg");

    try {
      getParameters();
//      manager = new KissManager();
      manager = new FKissManager((FKissNotify)this);
      if(zipfile!=null)zipLoad(zipfile,cfgfile);
      else load(cfgfile);

      setLayout(new BorderLayout());

//      ScrollPane pane = new ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED);

      Panel p;
      GridLayout layout;
      add(p = new Panel(layout = new GridLayout()),"North");
      p.add(ctl = new KissControler());
      ctl.setSize(160,32);

      KissCanvas c = new KissCanvas(manager);
/*
      pane.add(c);
      Adjustable vadjust = pane.getVAdjustable();
      Adjustable hadjust = pane.getHAdjustable();
      hadjust.setUnitIncrement(10);
      vadjust.setUnitIncrement(10);
      pane.setSize(640,400);
      add(pane,"Center");
*/
      add(c,"Center");
//      c.setSize(manager.getSize());
      ctl.setImage(gimg);
      ctl.setManager(manager);

    } catch (IOException e) { System.out.println(e);return ;}
  }

  public void setParameters(String[] str) {
    if(str.length>=1)cfgfile = str[0];
    if(str.length>=2)zipfile = str[1]; 
  }

  public void stop () {
    if(manager!=null) {
      manager.terminate();
    }
  }
}
