package jp.gr.java_conf.mith.kiss;
import jp.gr.java_conf.mith.kiss.*;

import java.awt.Point;

class CellLocation {
  int  paletteNumber = 0;
  Point pos[] = new Point[4096];
  int posmax =0;
  
  synchronized void setPaletteNumber(int num) {
    paletteNumber = num;
  }

  synchronized int getPaletteNumber(int num) {
    return paletteNumber;
  }

  synchronized void addPos(Point d) {
    pos[posmax++] = d;
  }

  synchronized void addPos(int x,int y) {
    pos[posmax++] = new Point(x,y);
  }

  synchronized void setPos(int i,Point d) {
    if(i<posmax) pos[i] = d;
  }

  synchronized void setPos(int i,int x,int y) {
    if(i<posmax) pos[i] = new Point(x,y);
  }

  synchronized Point getPos(int i) {
    if(i>= 0 && i<posmax) return pos[i];
    return null;
  }

  synchronized int getPosMax() {
    return posmax;
  }

}
