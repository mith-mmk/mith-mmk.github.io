package jp.gr.java_conf.mith.kiss;
import jp.gr.java_conf.mith.kiss.*;

// for FKISS Impl
public interface FKiss {
//EVENT
  public final int INITIALIZE = 0;
  public final int BEGIN      = 1;
  public final int END        = 2;
  public final int ALART      = 3;
  public final int PRESS      = 4;
  public final int RELEASE    = 5;
  public final int CATCH      = 6;
  public final int DROP       = 7;
  public final int FIXCATCH   = 8;
  public final int FIXDROP    = 9;
  public final int UNFIX      = 10;
  public final int SET        = 11;
  public final int COL        = 12;
//Reserved
  public final int IN         = 13;
  public final int OUT        = 14;
  public final int LEFTSIDE   = 15;
  public final int RIGHTSIDE  = 16;
  public final int UPSIDE     = 17;
  public final int STILLIN    = 18;
  public final int STILLOUT   = 19;
  public final int VERSION    = 20;
  public final int APART      = 21;
  public final int COLLIDE    = 22;

//ACTION
  public final int NOP        = 1000; 
  public final int SHELL      = 1001;
  public final int SOUND      = 1002;
  public final int UNMAP      = 1003;
  public final int MAP        = 1004;
  public final int ALTMAP     = 1005;
  public final int MOVE       = 1006;
  public final int CHANGESET  = 1007;
  public final int CHANGECOL  = 1008;
  public final int QUIT       = 1009;
  public final int DEBUG      = 1010;
  public final int RANDOMTIMER= 1011;
  public final int TIMER      = 1012;
  public final int TRANSPARENT= 1013;
//Reserved
  public final int MOVEBYE    = 1016;
  public final int MOVEBYY    = 1017;
  public final int MOVETO     = 1018;
  public final int MUSIC      = 1019;
  public final int IFFIXED    = 1020;
  public final int IFMOVED    = 1021;
  public final int IFNOTMAPPED= 1022;
  public final int IFNOTMOVED = 1023;
  public final int MOVERANDX  = 1024;
  public final int MOVERANDY  = 1025;
  public final int MOVTORAND  = 1026;
  public final int SETFIX     = 1027;

  static String eventName[] = {
     "initialize","begin","end","alarm","press","release","catch",
     "drop", "fixcatch","fixdrop","unfix","set","col",
     "in","out","leftside","rightside","upside","downside"
   };

  static String methodName[] = {
    "nop","shell","sound","unmap","map","altmap","move","changeset",
    "changecol","quit","debug","randomtimer","timer","transparent"
  };


}