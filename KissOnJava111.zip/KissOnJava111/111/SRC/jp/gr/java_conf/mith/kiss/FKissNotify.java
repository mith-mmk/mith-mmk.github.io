package jp.gr.java_conf.mith.kiss;
import jp.gr.java_conf.mith.kiss.*;

public interface FKissNotify extends FKiss {
  public void fkissNotify(int cmd,Object obj);
}
