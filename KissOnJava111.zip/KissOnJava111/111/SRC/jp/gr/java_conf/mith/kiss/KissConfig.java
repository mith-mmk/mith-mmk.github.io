package jp.gr.java_conf.mith.kiss;
import jp.gr.java_conf.mith.kiss.*;

import java.io.*;
import java.util.*;

public class KissConfig extends KissObject {
  String paletteFile[] = new String [256];
  CellArray cells[] ;
  private int celArraySize = 512;
  CellLocation location[] = new CellLocation[10];
  int palmax = 0;
  int celmax = 0;
  int backgroundPalette = 0;
  private String initLocation[] =new String[10];
  int width  = 448;  // 320
  int height = 320;  // 200
  int patternNum=0;
  int bx;

  public KissConfig(String name){
    super(name,KissObject.CONFIG);
    cells = new CellArray [celArraySize];
  }

  protected Hashtable events;
  protected Vector action;

  private void addStatement(String s[]) {
    for (int i = 0;i < FKiss.eventName.length ; i++ ){
      if(s[0].equals(FKiss.eventName[i])) {
        Hashtable h = (Hashtable)events.get(FKiss.eventName[i]);
        if(events.get(s[0])==null) {
          h = new Hashtable ();
          events.put(s[0],h);
        }
        action = new Vector();
        h.put(s[1].toLowerCase(),action);
        return ;
      }
    }

    for (int i = 0;i < FKiss.methodName.length ; i++ ){
      if(s[0].equals(FKiss.methodName[i])) {
        s[0] = Integer.toString(i + 1000);
        action.addElement(s);
      }
    }
  }

  private void addFKissStatement(String s0) {
    String s;
    if(s0.indexOf(';') != -1) {
      s = s0.substring(0,s0.indexOf(';'));
    } else {
      s = s0;
    }
    int i = 0 ;

    try {
      while(true) {
        String arg[] = new String[4];
        int argnum = 0;
        arg[0] = "";
        arg[1] = "";
        arg[2] = "";
        arg[3] = "";
        String str  = "";

        while (s.charAt(i) == ' ' || s.charAt(i) == '\t') i++;
        while (s.charAt(i) != ' ' && s.charAt(i) != '\t') {
          if(s.charAt(i) == '(')break;
          str += s.charAt(i);
          i++;
          if(s.length() <= i)break;
        }

        arg[argnum++] = str;
        if(arg[0].equals("EventHandler")) {
          events = new Hashtable();
          action = null;
          break;
        }

        while (s.charAt(i) == ' ' || s.charAt(i) == '\t') i++;
        if(s.charAt(i) != '(')break;
        i++;

        while(true) {
          str = "";
          while (s.charAt(i) == ' ' || s.charAt(i) == '\t') i++;
          if(s.charAt(i) == '#') {
            i++;
            while (s.charAt(i) != ' ' && s.charAt(i) != '\t') {
              if(s.charAt(i) == ')' || s.charAt(i)==',' )break;
              str += s.charAt(i);
              i++;
            }
          } else if(s.charAt(i) == '"') {
            i++;
            int escape = 0;
            char ch = s.charAt(i);
            while (true) {
              if(escape == 1) {
                escape=0;
                switch (ch) {
                case 't':
                  str += '\t';
                case 'n':
                  str += '\n';
                break;
                case '"':
                  str += '"';
                break;
                case 's':
                  str += ' ';
                break;
                default:
                  str += ch;
                }
              } else {
                if(ch == '\\') {
                  escape = 1;
                }else if(ch == '"') {
                  i++;break;
                } else {
                    str += ch;
                }
              }
              ch = s.charAt(++i);
            }
          
          } else if (s.charAt(i) == ')') {
            break;
          } else {
            while (s.charAt(i) != ' ' && s.charAt(i) != '\t') {
              if(s.charAt(i) == ')' || s.charAt(i)==',' )break;
              str += s.charAt(i);
              i++;
            }
          }
          arg[argnum++] = str;
          while (s.charAt(i) == ' ' || s.charAt(i) == '\t') i++;
          if(s.charAt(i) == ')')break;
          while (s.charAt(i) != ',')break;
          i++;
        }
        if(s.charAt(i) != ')')break;
        i++;

        addStatement(arg);
       }
    } catch (Exception e) { }
  }


  public void load(InputStream in) throws IOException {
    load(in,"SJIS");
  }



  public void load(InputStream in,String code) throws IOException {
    String str,s,s0,comment;
    for(int i=0;i<10;i++) initLocation[i] = "";

    try {
      BufferedReader din = new BufferedReader(new InputStreamReader(in,code));
      while(true) {
        s0 = din.readLine();
        if(s0 == null)break;
        if(s0.length() == 0)continue;

        if(s0.indexOf(";@") == 0) {
          addFKissStatement(s0.substring(2));
          continue;
        }
        if(s0.indexOf(';') != -1) {
          s = s0.substring(0,s0.indexOf(';'));
          comment = s0.substring(s0.indexOf(';')+1);
        } else {
          s = s0;
          comment = "";
        }
        if(s.length() == 0)continue;

        switch(s.charAt(0)) {

        case '(':  // size
          try {
            int i = 1;
            str = "";
            while(s.charAt(i) != ' ' && s.charAt(i) != '\t' && s.charAt(i) != ',') {
            str += s.charAt(i++);
            }
            width = Integer.parseInt(str);

            while(s.charAt(i) == ',' ) i++;
            while(s.charAt(i) == ' ' || s.charAt(i) == '\t' ) i++;

            str = "";
            while(s.charAt(i) != ' ' && s.charAt(i) != '\t' && s.charAt(i) !=')') {
            str += s.charAt(i++);
            if(s.length() <= i)break;
            }
            height = Integer.parseInt(str);

          }catch (NumberFormatException e){
            err = "Illigal format in Configfile";
          }
          
        break;

        case '[':  // back palette
          try {
            str = "";
            for(int i=1 ; i < s.length() ; i++ ) {
              if(s.charAt(i) == ' ' || s.charAt(i) == '\t')break;
              str += s.charAt(i);
            }
            backgroundPalette = Integer.parseInt(str);
          }catch (NumberFormatException e){
            err = "Illigal format in Configfile";
          }
        break;

        case '%':  // palette file
          str="";
          for(int i=1 ; i<s.length() ; i++ ) {
            switch(s.charAt(i)){
            case ';':
            case ' ':
            case '\t':
             i=s.length();
            break ;

            default:
              str += s.charAt(i);

            }
          }
          outloop:
          paletteFile[palmax++]=str;
        break;

        case '#':  // cel file
          int id;
          int fixed=0;
          String celfile = "";
          int i=1;
          int basepix = 0;
          boolean v[] = new boolean[10];

          str = "";
          while(s.charAt(i) != ' ' && s.charAt(i) != '\t' && s.charAt(i) != '.' ) {
            str += s.charAt(i++);
          }

          id = Integer.parseInt(str);

          if(s.charAt(i) == '.') {
            str = "";i++;
            while(s.charAt(i) != ' ' && s.charAt(i) != '\t' ) {
              str += s.charAt(i++);
            }
            fixed = Integer.parseInt(str);
          }

          while(s.charAt(i) == ' ' || s.charAt(i) == '\t') i++;

          str = "";
          while(s.charAt(i) != ' ' && s.charAt(i) != '\t' ) {
            str += s.charAt(i++);
            if(s.length()<=i) break;
          }
          celfile = str;

          if(s.length()>i) {
            while(s.charAt(i)!='*' && s.charAt(i)!=':')
            {
              i++;
              if(s.length()<=i) break;
            }
          }

          if(s.length()>i) {
            if(s.charAt(i) == '*') {
              str = "";i++;
              while(s.charAt(i) != ' ' && s.charAt(i) != '\t' && s.charAt(i) != ':') {
                str += s.charAt(i++);
              }
              bx = Integer.parseInt(str);
              while(s.charAt(i) == ' ' || s.charAt(i) == '\t'){
               i++;
               if(s.length()>=i)break;
              }
            }
          }

          if(s.length()>i) {
            while(s.charAt(i) != ':')
            {
              i++;
              if(s.length()<=i) break;
            }
          }

          for(int t=0;t<10;t++) v[t]=true;

          if(s.length()>i) {
            if(s.charAt(i)==':') {
              for(int t=0;t<10;t++) {
                v[t]=false;
              }
              while(s.length()>i) {
                if(s.charAt(i)>='0' && s.charAt(i)<='9') {
                  v[s.charAt(i) - "0".charAt(0)] = true;
                }
                i++;
              }
            }
          }

          cells[celmax++] = new CellArray(celfile,id,bx,fixed,v,comment);
          if(celmax==celArraySize) {
            celArraySize *= 2;
            CellArray array[] = new CellArray[celArraySize];
            System.arraycopy(cells,0,array,0,celmax);
            cells = array;
          }
        break;

        case '$':  // location
          patternNum = 0;
          initLocation[patternNum] += s.substring(1);
          while(true) {
            s = din.readLine();
            if(s == null)break;
            if(s.length() == 0)continue;
            if(s.charAt(0) == ';') continue;
            if(s.charAt(0) != '$') {
              initLocation[patternNum] += s;
            } else {
              initLocation[++patternNum] += s.substring(1);
            }
          }
          patternNum ++ ; 
        break;

        }
      }
    } catch (IOException e) {
      err = "Cannot access file or end of config file.";
      return;
    } 
    for (int i=0;i<patternNum;i++) {
      location[i] = setLocation(initLocation[i]);
    }
 }

  private CellLocation setLocation(String s) {
    String str = "";
    CellLocation l = new CellLocation();
    int x,y,i,j,k;
    i=0;
    try {
      while(s.charAt(i) != ' ' && s.charAt(i) != '\t' ) {
        str += s.charAt(i++);
        if(s.length() <= i)break;
      }
      l.setPaletteNumber(Integer.parseInt(str));
      while(s.charAt(i) == ' ' || s.charAt(i) == '\t' ) i++;
      k=0;j=0;
      for(j=0;j<celmax;) {
        if(s.length() <= i) break;
        if(s.charAt(i) == '*') {
          i++;
          if(s.length() > i) {
            while(s.charAt(i) == ' ' || s.charAt(i) == '\t' ) {
              i++;
              if(s.length() <= i)break;
            }
          }
          x = 0;
          y = 0;
        } else {
          str = "";
          while(s.charAt(i) != ' ' && s.charAt(i) != '\t' && s.charAt(i) != ','){
            str += s.charAt(i++);
            if(s.length() <= i) break;
          }
          x = Integer.parseInt(str);

          while(s.charAt(i) == ',' ) i++;
          while(s.charAt(i) == ' ' || s.charAt(i) == '\t' ) i++;

          if(s.length() <= i)break;
          str = "";
          while(s.charAt(i) != ' ' && s.charAt(i) != '\t' ) {
            str += s.charAt(i++);
            if(s.length() <= i)break;
          }
          y = Integer.parseInt(str);

          if(s.length() > i) {
            while(s.charAt(i) == ' ' || s.charAt(i) == '\t' ) i++;
          }
        }
        l.addPos(x,y);
        k++;
      }
      return l;
    } catch (Exception e) {return l;}
  }

  int getPaletteNumber(int num) {
    return location[num].getPaletteNumber(num);
  }

  public int getMaxColorSet() {
    return palmax;
  }

  public String getPaletteFile(int i) {
    return paletteFile[i];
  }

  public int getMaxCellNumber() {
    return celmax;
  }

  public String getCellFilename(int i) {
    return cells[i].getFilename();
  }

}
