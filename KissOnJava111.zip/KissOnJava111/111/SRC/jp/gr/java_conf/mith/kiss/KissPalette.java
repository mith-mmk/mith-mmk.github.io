package jp.gr.java_conf.mith.kiss;
import jp.gr.java_conf.mith.kiss.*;

//KissPalette class
// Kiss on Java 0.1.1 by MITH@mmk  1996/07/27

import java.awt.*;
import java.awt.image.*;
import java.applet.*;
import java.net.*;
import java.io.*;

public class KissPalette extends KissObject {
  byte r[][] =new byte[10][256];
  byte g[][] =new byte[10][256];
  byte b[][] =new byte[10][256];
  byte a[][] =new byte[10][256];

  int base[] = new int[256];
  int col = 0;
  int maxBase = 0;
  int nowBase = 0;

  int colorset = 0;

  public KissPalette(String name){super(name,KissObject.PALETTE);}

  public void load(InputStream in) throws IOException {
    colorset = readKcf(in);
  }

  public void append (KissPalette kp) {
    if(nowBase==0) {
      for(int i=0;i<10;i++) {
        r[i][0] = kp.r[i][0];
        g[i][0] = kp.g[i][0];
        b[i][0] = kp.b[i][0];
        a[i][0] = kp.a[i][0];
      }
    }

    for(int i=0;i<10;i++) {
      for(int j=nowBase + 1,k = 1;k < kp.nowBase + 1;j++,k++) {
        r[i][j] = kp.r[i][k];
        g[i][j] = kp.g[i][k];
        b[i][j] = kp.b[i][k];
//        a[i][j] = kp.a[i][k];
        a[i][j] = (byte)0xff;
      }
    }
    for(int i=0;i<kp.maxBase;) {
      base[maxBase++]= nowBase  + kp.base[i++];
    }
    nowBase += kp.nowBase ;
    if(colorset == 0) {
      colorset = kp.colorset;
    } else if(kp.colorset > 0) {
      colorset = Math.min(colorset,kp.colorset);
    }


  }

  private int readPal(DataInputStream din,int ppb,int pal,int palset) throws IOException{
    int i = 0;
    try {
      for(i=0;i<palset;i++) {
        if(ppb == 12) {
          a[i][0] = (byte)0x00;
          for(int j= 1;j< pal;j++) {
            a[i][j] = (byte)0xff;
          }

          for(int j=0;j< pal;j++) {
            int pal1 = din.readUnsignedByte();
            int pal2 = din.readUnsignedByte();
            r[i][j] = (byte) ((pal1>>4)   * 0x11);
            b[i][j] = (byte) ((pal1&0x0f) * 0x11);
            g[i][j] = (byte) ((pal2&0x0f) * 0x11);
          }
        } else if(ppb == 24) {
          a[i][0] = (byte)0x00;
          for(int j= 1 ;j< pal;j++) {
            a[i][j] = (byte)0xff;
          }

          for(int j=0 ;j< pal;j++) {
            r[i][j] = (byte) din.readUnsignedByte();
            g[i][j] = (byte) din.readUnsignedByte();
            b[i][j] = (byte) din.readUnsignedByte();
          }
        }
      }
    } catch (EOFException e) {  }

    int palmax = i;

    for(i = palset ;i<10;i++) {
      for(int j=0 ;j< pal;j++) {
        r[i][j] = r[0][j];
        g[i][j] = g[0][j];
        b[i][j] = b[0][j];
      }
    }

    base[0] = 0;
    maxBase = 1;
    nowBase = pal - 1;
    
    return palmax;
  }

  private int readPal(DataInputStream din,int p0,int p1,int p2,int p3) throws IOException{
    {
      a[0][0] = (byte)0x00;
      for(int j= 1;j< 16;j++) {
        a[0][j] = (byte)0xff;
      }
      int pal1 = p0;
      int pal2 = p1;
      r[0][0] = (byte) ((pal1>>4)   * 0x11);
      b[0][0] = (byte) ((pal1&0x0f) * 0x11);
      g[0][0] = (byte) ((pal2&0x0f) * 0x11);

      pal1 = p2;
      pal2 = p3;

      r[0][1] = (byte) ((pal1>>4)   * 0x11);
      b[0][1] = (byte) ((pal1&0x0f) * 0x11);
      g[0][1] = (byte) ((pal2&0x0f) * 0x11);

      for(int j= 2;j< 16;j++) {
        pal1 = din.readUnsignedByte();
        pal2 = din.readUnsignedByte();
        r[0][j] = (byte) ((pal1>>4)   * 0x11);
        b[0][j] = (byte) ((pal1&0x0f) * 0x11);
        g[0][j] = (byte) ((pal2&0x0f) * 0x11);
      }
    }

    int i = 1;

    try {
      for(i=1;i<10;i++) {
        a[i][0] = (byte)0x00;
        for(int j= 1;j< 16;j++) {
          a[i][j] = (byte)0xff;
        }

        for(int j= 0 ;j< 16;j++) {
          int pal1 = din.readUnsignedByte();
          int pal2 = din.readUnsignedByte();
          r[i][j] = (byte) ((pal1>>4)   * 0x11);
          b[i][j] = (byte) ((pal1&0x0f) * 0x11);
          g[i][j] = (byte) ((pal2&0x0f) * 0x11);
        }
      }
    } catch (EOFException e) { }

    int palmax = i;

    base[0]= 0;
    maxBase = 1;
    nowBase = 16 - 1;
    
    return palmax;
  }

  private int readKcf(InputStream fin) throws IOException{
    DataInputStream din = new DataInputStream(fin);

    int c0 = din.readUnsignedByte();
    int c1 = din.readUnsignedByte();
    int c2 = din.readUnsignedByte();
    int c3 = din.readUnsignedByte();

    if(c0==0x4B && c1==0x69 && c2 == 0x53 && c3 == 0x53) {  //"KiSS"
      int palmark = din.readByte();
      int ppb     = din.readByte();
      int res = din.readByte();
      res = din.readByte();

      int p0 = din.readUnsignedByte();
      int p1 = din.readUnsignedByte();
      int pal = p0 | (p1 << 8);

      int p2 = din.readUnsignedByte();
      int p3 = din.readUnsignedByte();
      int palset = p2 | (p3 << 8);

      res = din.readByte();
      res = din.readByte();

      res = din.readByte();
      res = din.readByte();

      for(int i=0 ; i< 16 ; i++) {
        res = din.readByte();
      }
      return readPal(din,ppb,pal,palset);
    } else {
      din = new DataInputStream(fin);
      return readPal(din,c0,c1,c2,c3);
    }
  }

  int getPaletteBase(int num) {
    return base[num];
  }

  IndexColorModel getSelectedPalette(int paletteSelect) {
    int i = paletteSelect;
    col = i;
    return new IndexColorModel(8,256,r[i],g[i],b[i],a[i]);
  }

  Color getSelectedColor(int num) {
    return new Color(((int)r[col][num])&0xff,((int)g[col][num])&0xff,((int)b[col][num])&0xff);
  }
  
  int getMaxColorSet() {
    return colorset;
  }

}
