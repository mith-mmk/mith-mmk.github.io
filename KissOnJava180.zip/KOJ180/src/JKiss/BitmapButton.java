package JKiss;
import java.awt.*;
import java.awt.event.*;

  public class BitmapButton extends Button {
  /**
	 * 
	 */
  private static final long serialVersionUID = 7038355448622551160L;
  private boolean me = false;
//  private int dxChar=0,dyChar=0;
  private Dimension buttonSize = new Dimension(-1,-1);

  Image normalStatusImage;
  Image mouseOverImage;
  Image pushButtonImage;
  Image disableButtonImage;
  Image img;


  String actionCommand;
  transient ActionListener actionListener;

  @Override
public synchronized Dimension getMinimumSize() {
    return buttonSize;
  }

  @Override
public synchronized Dimension getPreferredSize() {
    return buttonSize;
  }

  public void setButtonSize(int width,int height) {
    buttonSize.width = width;
    buttonSize.height= height;
  }

  public BitmapButton(String label) {
    this(label,8,8,(Image)null,(Image)null,(Image)null);
  }

  public BitmapButton(String label,int width,int height) {
    this(label,width,height,(Image)null,(Image)null,(Image)null);
  }

  public BitmapButton(String label,int width,int height,Image img) {
    this(label,width,height,img,img,img);
  }

  public BitmapButton(String label,int width,int height,Image img,Image img2) {
    this(label,width,height,img,img,img2);
  }

  public BitmapButton(String label,int width,int height,Image img1,Image img2,Image img3) {
    setButtonSize(width,height);
    normalStatusImage = img1;
    mouseOverImage    = img2;
    pushButtonImage   = img3;
    this.img = normalStatusImage;
    setLabel(label);
    enableEvents(AWTEvent.ACTION_EVENT_MASK | AWTEvent.MOUSE_EVENT_MASK);
    repaint();
  }

  @Override
public void paint(Graphics g) {
    Dimension d = getSize();

    g.setColor(getBackground());
    g.fillRect(0,0,d.width,d.height);
    if(img!=null)g.drawImage(img,0,0,d.width,d.height,this);
  }

  @Override
public void processMouseEvent(MouseEvent e) {
//    Graphics g;
    switch(e.getID()) {
    case MouseEvent.MOUSE_PRESSED:
      me = true;
      img = pushButtonImage;
      repaint();
      break;
    case MouseEvent.MOUSE_RELEASED:
      if(me == true) {
        me = false;
      }
      img = normalStatusImage;
      repaint();
      break;

    case MouseEvent.MOUSE_EXITED:
      if(me == true) {
        me = false;
      }
      img = normalStatusImage;
      repaint();
      break;
    case MouseEvent.MOUSE_ENTERED:    
      img = mouseOverImage;
      repaint();
      break;
    }
    super.processMouseEvent(e);
  }
}
