package JKiss;
/*
// KissControler  1998/02/01 MITH@mmk
// Kiss���[�_�[�̃R���g���[���������Ȃ��N���X
// cfg file�̐؂�ւ��A�p���b�g�̐؂�ւ��A�C���[�W�p�^�[���̐؂�ւ����o����
// ~~~~~~~~~~~~~~~~~~���܂��ł��܂���E�E�E
// 
// KissManager���g�����āAKissControl�ŃC�x���gnotify����\��E�E�E�B
// �O���ˑ��@�\���C���v���ł���E�E�j
//
*/
import java.awt.*;
import java.awt.event.*;

import jp.gr.java_conf.mith.Kiss.*;

public class KissControler extends Panel {
  /**
	 * 
	 */
	private static final long serialVersionUID = 742427706934460900L;
Image img,gimg;
  int sx=0,sy=0;
  Graphics grp;
  Rectangle pattern[] = new Rectangle[10];
  Rectangle palette[] = new Rectangle[10];
  FontMetrics fm;Font font;int fh;

  KissManager manager = null;

  public void setImage(Image img) {
    gimg = img;
  }

  KissControler () {
    gimg = null;
    enableEvents(AWTEvent.MOUSE_EVENT_MASK);
    setSize(160,32);
    int i;
    for(i=1;i<16;i++) {
      fm = getFontMetrics(new Font("SansSerif",Font.BOLD,i));
      if(fm!=null) {
        int h = fm.getAscent();
        int w = fm.getMaxAdvance();
        if(h>=16 || w>=16)break;
      }
    }
    font = new Font("SansSerif",Font.BOLD,i-1);
    fm   = getFontMetrics(font);
    fh   = fm.getAscent();
  }

  @Override
public void update(Graphics g) {
    paint(g);
  }

  public void setManager(KissManager m) {
    manager = m;
    repaint();
  }

  public void reflesh() {
    repaint();
  }

  void drawSelect(Graphics g) {
    int pal,pat;
//    int palmax;
    boolean b1[] = new boolean [10];
    boolean b2[] = new boolean [10];

    if(manager != null ) {
      if(manager.getLoaded()){
        pal = manager.getSelectPalette();
        pat = manager.getSelectPattern();
        manager.getSetEnable (b1);
        manager.getColEnable (b2);
      } else {
        pal = -1;pat = -1;
        for(int i=0;i<10;i++){b1[i]=false;b2[i]=false;};
      }
    } else {
      pal = -1;pat = -1;
      for(int i=0;i<10;i++){b1[i]=false;b2[i]=false;};
    }

    if(grp ==null) {
       img= createImage(161,33);
       grp = img.getGraphics();
    }
    grp.clearRect(0,0,161,33);
    grp.setFont(font);
    int y = 16 - (16 - fh + 1) /2;

    for(int i=0;i<10;i++) {
      grp.setColor(Color.black);
      grp.drawRect(i * 16 ,  0, 16, 16);
      grp.drawRect(i * 16 , 16, 16, 16);
      if(!b1[i]) {
        grp.setColor(Color.lightGray);
        grp.fillRect(i * 16 + 1,  1, 15, 15);
      }
      if(i==pat) {
        grp.setColor(Color.red);
        grp.fillRect(i * 16 + 1,  1, 15, 15);
      }
      if(!b2[i]) {
        grp.setColor(Color.lightGray);
        grp.fillRect(i * 16 + 1, 17, 15, 15);
      }
      if(i==pal) {
        grp.setColor(Color.red);
        grp.fillRect(i * 16 +1 , 17, 15, 15);
      }
      grp.setColor(Color.black);
      String s =Integer.toString(i);
      int fw = fm.stringWidth(s);
      int x = i * 16 + (16 - fw + 1) / 2;
      grp.drawString(s,x,y);
      grp.drawString(s,x,y+16);
    }
    Dimension d = getSize();
    sx = (d.width - 162 );
    sy = (d.height- 33  )/ 2;
    g.drawImage(img,sx,sy,this);
  }

  @Override
public void paint (Graphics g) {
    Dimension d = getSize();
    Image imgBuffer = createImage(d.width,d.height);
    Graphics gg = imgBuffer.getGraphics();
    gg.clearRect(0,0,d.width,d.height);
    if(gimg!=null)gg.drawImage(gimg,0,0,this);
    drawSelect(gg);
    g.drawImage(imgBuffer,0,0,this);
  }

  @Override
protected void processMouseEvent(MouseEvent e) {
    int x = e.getX();
    int y = e.getY();
//    int m = e.getModifiers();
    switch(e.getID()) {
      case MouseEvent.MOUSE_PRESSED:
        if(manager!=null)if(manager.getLoaded())click(x,y);
      break;
    }
    super.processMouseMotionEvent(e);
  }

  void click(int x,int y) {
    x -= sx;
    y -= sy;

    if(manager != null) {
      int posx = x/16;
      int posy = y/16;
      if(posx>=0 && posx<= 9) {
        if(posy==0) {
          boolean b[] = new boolean [10];
          manager.getSetEnable (b);
          if(b[posx])manager.setSelectPattern (posx);
          repaint();
        } else if(posy==1) {
          boolean b[] = new boolean [10];
          manager.getColEnable (b);
          if(b[posx])manager.setSelectPalette (posx);
          repaint();
        }
      }
    }
  }

  @Override
public Dimension getMinimumSize() {
    return new Dimension(161,40);
  }

  @Override
public Dimension getPreferredSize() {
    return new Dimension(161,40);
  }


}
