package jp.gr.java_conf.mith.Kiss;

public class CellArray {
  String filename;
  int     id;
  int     base;
  int     fixed;
  boolean visible[] = new boolean[10];
  String  comment = "";

  public String getFilename() {
    return filename;
  }

  public int getID() {
    return id;
  }

  public CellArray (String name,int id,int base,int fixed,boolean visible[]) {
    this(name,id,base,fixed,visible,"");
  }

  public CellArray (String name,int id,int base,int fixed,boolean visible[],String comment) {
     this.filename = name;
     this.id       = id;
     this.base     = base;
     this.fixed    = fixed;
     this.visible  = visible;
     this.comment  = comment;
  }
}
