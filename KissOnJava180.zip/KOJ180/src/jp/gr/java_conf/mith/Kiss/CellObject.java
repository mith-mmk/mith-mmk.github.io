package jp.gr.java_conf.mith.Kiss;
import java.awt.*;

import java.util.*;

class CellObject {
  int x,y;
  private int px,ox;
  private int py,oy;
  int xpos[] = new int [10];
  int ypos[] = new int [10];
  int width,height;
  int fixed;
  int pesi;
  int moveLimit;
  int pesiLimit;
  int current = -1;
  String comment[];
  KissCell cells[];

  CellObject (Vector<KissCell> list) {
    fixed = 0;
    pesi = 0;
    cells = new KissCell[list.size()];
    comment = new String[list.size()+1];
    for(int i = 0 ; i< list.size() ; i++ ) {
      KissCell cell = list.elementAt(i);
      Dimension d = cell.getSize();
      cells[i] = cell;
      if(d.width  > width) width=d.width;
      if(d.height > height ) height=d.height;
      fixed += cell.fixed;
      comment[i+1] = cells[i].objectNumber + ": " +cell.comment;
    }
    if(list.size()>0)comment[0] = "#" + cells[0].id;
  }

  void  setCurrent(int i) {
//    if(current == i) return ;
    if(current > 0) {
      xpos[current]  = x;
      ypos[current]  = y;
    }
    current = i;
    setPos(xpos[i],ypos[i]);
  }


  void setPos(int x,int y) {
    this.x = x;
    this.y = y;
    px = x;
    py = y;
    ox = x;
    oy = y;
    for(int i=0;i<cells.length;i++) {
      cells[i].setPos(x,y);
    }
  }

  void setDefaultPos(int x,int y,int u) {
    xpos[u] = x;
    ypos[u] = y;
    current = u;
    for(int i=0;i<cells.length;i++) {
      cells[i].setPos(x,y);
    }
  }

  void addPos(int dx,int dy) {
    px = x;
    py = y;
    x += dx;
    y += dy;
    ox = x;
    oy = y;
    for(int i=0;i<cells.length;i++) {
      cells[i].setPos(x,y);
    }
  }

  void addPos(int dx,int dy,int w,int h) {
    px = x;
    py = y;
    ox += dx;
    oy += dy;

    if(ox<0)x=0;
    else if(ox + width>= w) x= w - width - 1;
    else x = ox;
    if(oy<0) y=0;
    else if(oy + height >= h) y= h - height- 1;
    else y = oy;

    for(int i=0;i<cells.length;i++) {
      cells[i].setPos(x,y);
    }
  }

  Rectangle getClipSize()  {
     int x = Math.min(px,this.x) ;
     int y = Math.min(py,this.y) ;
     int w  = this.width + Math.max(px,this.x) ;
     int h  = this.height + Math.max(py,this.y) ;
     return new Rectangle(x,y,w,h);
  }

  boolean isFix() {
    if(fixed <= pesi) return false;
    return true;
  }

  int subFix(int c) {
    pesi += c;
    if (pesi > fixed)pesi = fixed;
    return pesi;
  }

  int getPesiLimit() {
    return (pesi / 20) + 1;
  }
  int getMoveLimit(int i) {
    return (pesi+i)*16 / fixed + 1;
  }

  void setVisible(boolean flag) {
    for(int i=0;i<cells.length;i++) {
      cells[i].setVisible(flag);
    }
  }

  void setVisible() {
    for(int i=0;i<cells.length;i++) {
      cells[i].setVisible();
    }
  }

}
