package jp.gr.java_conf.mith.Kiss;
import java.awt.*;
import java.util.*;


public class FKissManager extends KissManager {
  Random rnd = new Random();
  FKissAlarm alarm;
  private FKissNotify f = null;

  public FKissManager(Component c,FKissNotify f) {
    super(c);
    this.f = f;
  }

  public FKissManager(FKissNotify f) {
    super();
    this.f = f;
  }

  public FKissManager() {
    super();
  }

  public FKissManager(Component c) {
    super(c);
  }

  class FKissAlarm extends Thread {
    FKissManager manager;
    int num;
    Hashtable<?, ?> h;
    long t[];

    private int s[] ;
    boolean resetFlag[];
    private int u;
 
    FKissAlarm(FKissManager m,Hashtable<?, ?> h,int n) {
      manager = m;
      num = n;
      t = new long [n];
      for(int i=0;i<n;i++) t[i] = Long.MAX_VALUE;
      this.h = h;
      s = new int [num];
      resetFlag = new boolean [num];
      u = 0;
    }

    synchronized void setTimer(int id,int time){
      for(int i=0;i<u;i++)
        if(id == s[i])if(resetFlag[i])return;

      t[id] = new Date().getTime() + (long)time;
    }

    synchronized void resetTimer(int id){
      t[id] = Long.MAX_VALUE;
      for(int i=0;i<u;i++)
        if(id == s[i])resetFlag[i] = true;
    }
    

    public void run() {
      try {
        while(true) {
          Thread.sleep(1);
          long n = new Date().getTime();
          for(int i=0;i<num;i++) {
            if(t[i]<=n) {
              resetFlag[u] = false;
              s[u++] =i;
              t[i] = Long.MAX_VALUE;
            }
          }
          for(int i=0;i<u;i++) {
            manager.decodeCommand((Vector<?>)h.get(Integer.toString(s[i])));
          }
          u = 0;
        }
      } catch (InterruptedException e){System.err.println(e);}
    }
  }

  synchronized void setTimer(int id,int time,int area) {
    if(area == 0)area = 1;
    int t = time + (Math.abs(rnd.nextInt()) % area);

    if(time == 0){
      alarm.resetTimer(id);
      return;
    }
    alarm.setTimer(id,t);
  }


  KissCell searchCell(String name) {
    KissCell cell=null;
    name = name.toLowerCase();
    for(int i=0;i<cnf.celmax;i++) {
      if(name.equalsIgnoreCase(cells[i].name)) {
        cell = cells[i];
        break;
      }
    }
    return cell;
  }

  void mapCell(String name ) {
    KissCell cell=searchCell(name);
    try {
      if(cell==null) {
        int id = Integer.parseInt(name);
        cobj[id].setVisible();
        executeClipRect(id);
      } else {
        cell.setVisible();
        executeClipRect(cell.id);
      }
    }catch (Exception e){}
  }

  void mapCell(String name,boolean flag) {
    KissCell cell=searchCell(name);
    try {
      if(cell==null) {
        int id = Integer.parseInt(name);
        cobj[id].setVisible(flag);
        executeClipRect(id);
      } else {
        cell.setVisible(flag);
        executeClipRect(cell.id);
      }
    }catch (Exception e){}

  }

  synchronized void moveCell(int id,int dx,int dy) {
    if(loaded == false)return ;
    executeClipRect(id,dx,dy);
    cobj[id].addPos(0,0);
  }

  synchronized boolean decodeCommand(Vector<?> commandSet) {
    if(commandSet == null)return false;
    for(int i=0;i<commandSet.size();i++) {
      String cmdStr[] = (String [])commandSet.elementAt(i);
      decodeMethod(cmdStr);
    }
    if(ra!=null)component.repaint();
    return true;
  }

  Vector<?> getHandleEvent(String key) {
    if(cnf.events==null)return null;
    Hashtable<?, ?> h = cnf.events.get(key);
    if(h==null)return null;
    return (Vector<?>) h.get("");
  }

  Vector<?> getHandleEvent(String key,String key2) {
    if(cnf.events==null)return null;
    Hashtable<?, ?> h = cnf.events.get(key);
    if(h==null)return null;
    return (Vector<?>) h.get(key2);
  }


  Hashtable<?, ?> getHandleEvents(String key) {
    if(cnf.events==null)return null;
    return cnf.events.get(key);
  }

  void decodeMethod(String arg[]) {
    if(loaded == false)return ;
    final int cmd = Integer.parseInt(arg[0]);
//    System.out.println(arg[0] +" : " + arg[1] + " " + arg[2] + " " + arg[3]);

    switch(cmd) {
      case FKiss.NOP        :
      break;
      case FKiss.SHELL      :  // No impl
        shell(arg[1]);
      break;
      case FKiss.SOUND      :  // No impl
        playsound(arg[1]);
      break;
      case FKiss.UNMAP      :
        mapCell(arg[1],false);
      break;
      case FKiss.MAP        :
        mapCell(arg[1],true);
      break;
      case FKiss.ALTMAP     :
        mapCell(arg[1]);
      break;
      case FKiss.MOVE       :
        moveCell(Integer.parseInt(arg[1]),Integer.parseInt(arg[2])
                      ,Integer.parseInt(arg[3]));
      break;
      case FKiss.CHANGESET  :
        setSelectPattern(Integer.parseInt(arg[1]));
      break;
      case FKiss.CHANGECOL  :
        setSelectPalette(Integer.parseInt(arg[1]));
      break;
      case FKiss.QUIT       :
        quit();
      break;
      case FKiss.DEBUG      :
        debug(arg[1]);
      break;
      case FKiss.RANDOMTIMER:
         setTimer(Integer.parseInt(arg[1]),Integer.parseInt(arg[2])
                      ,Integer.parseInt(arg[3]));
      break;
      case FKiss.TIMER      :
         setTimer(Integer.parseInt(arg[1]),Integer.parseInt(arg[2]),1);
      break;
      case FKiss.TRANSPARENT :
         setTransparent(arg[1],Integer.parseInt(arg[2]));
      break;
    }
  }

  void setTransparent(String name,int count) {
    KissCell cell = searchCell(name);
    cell.addTransparentOrder(count);
    cell.getImage(icm,component);
    executeClipRect(cell);
 }

  public synchronized void begin () {
    decodeCommand(getHandleEvent("begin"));
  }


  public synchronized void initialize (int num) {
    if(cnf.events==null)return;
    setAlart();
    decodeCommand(getHandleEvent("initialize"));
    ra = null;
  }

 @SuppressWarnings("deprecation")
public synchronized void terminate () {
    if(cnf==null)return ;
    if(cnf.events==null)return ;
    decodeCommand(getHandleEvent("end"));
    alarm.stop();
    loaded = false;
  }

  synchronized void quit () {  //no imple
    if(f!=null)f.fkissNotify(FKiss.QUIT,null);
  }

  synchronized void playsound (String name) {  //no imple
    if(f!=null)f.fkissNotify(FKiss.SOUND,name);
  }

  synchronized void shell(String command) {  //no imple
    if(f!=null)f.fkissNotify(FKiss.SHELL,command);
  }

  void debug(String str) {
        System.out.println(str);
  }

  synchronized void setAlart() {
    Hashtable<?, ?> h = getHandleEvents("alarm");
    Enumeration<?> key = h.keys();
    if(h.size()>0) {
      int arraysize = 0;
      while(key.hasMoreElements()) {
        String evt = (String)key.nextElement();
        int t = Integer.parseInt(evt);
        if(t>arraysize)arraysize = t;
      }
      alarm = new FKissAlarm(this,h,++arraysize);
      alarm.start();
    }
  }

  int pressID;
  String pressCellName;

  void runCommand(int id,int x,int y,String str) {
    if(cnf.events==null)return;
    decodeCommand(getHandleEvent(str,Integer.toString(id)));
    Hashtable<?, ?> h = getHandleEvents(str);
    if(h==null)return ;
    for(int i=0;i < cnf.celmax ; i++) {
      if(cells[i].isMoveImage(x,y,patternSelect)) {
        Vector<?> v = (Vector<?>)h.get(cells[i].name);
        if(v!=null) {
           decodeCommand(v);
           return;
        }
      }
    }
  }

  void pressEvent(int id,int x,int y){
    if(cnf.events==null)return;
    String str = "press";
    pressCellName = "";

    Vector<?> v = getHandleEvent(str,Integer.toString(id));
    if(v!=null) {
      pressID = id;
      decodeCommand(v);
      return ;
    }
    Hashtable<?, ?> h = getHandleEvents(str);
    if(h==null)return ;
    int i;
    for(i=0;i < cnf.celmax ; i++) {
      if(cells[i].isMoveImage(x,y,patternSelect)) {
        v = (Vector<?>)h.get(cells[i].name);
        if(v!=null) {
           decodeCommand(v);
           break;
        }
      }
    }
    if(v!=null){pressCellName = cells[i].name;pressID = -1;}
  }

  void releaseEvent(int x,int y){
    if(cnf.events==null)return;
    String str = "release";
    if(pressID!=-1) {
      decodeCommand(getHandleEvent(str,Integer.toString(pressID)));
    } else {
      Hashtable<?, ?> h = getHandleEvents(str);
      if(h!=null) {
        Vector<?> v = (Vector<?>)h.get(pressCellName);
        if(v!=null) {
          decodeCommand(v);
        }
      }
    }
    pressCellName = "";
    pressID = -1;
  }

  void dropEvent(int id,int x,int y){
    runCommand(id,x,y,"drop");
  }

  void fixedDropEvent(int id,int x,int y){
    runCommand(id,x,y,"fixdrop");
  }

  void unfixedEvent(int id,int x,int y) {
    runCommand(id,x,y,"unfix");
  }

  void fixedCatchEvent(int id,int x,int y) {
    runCommand(id,x,y,"fixcatch");
  }

  void catchEvent(int id,int x,int y) {
    runCommand(id,x,y,"catch");
  }

  public synchronized void setSelectPattern(int num) {
    produceImage (num);
    component.repaint();
    if(f!=null)f.fkissNotify(FKiss.SET,Integer.valueOf(num));
    if(!decodeCommand(getHandleEvent("set",Integer.toString(num)))) {
      component.repaint();
    }
  }

  public synchronized void setSelectPalette(int num) {
    producePalette (num);
    if(f!=null)f.fkissNotify(FKiss.COL,Integer.valueOf(num));
    if(!decodeCommand(getHandleEvent("col",Integer.toString(num)))) {
      component.repaint();
    }
  }

}
