package jp.gr.java_conf.mith.Kiss;

public interface FKissNotify extends FKiss {
  public void fkissNotify(int cmd,Object obj);
}
