package jp.gr.java_conf.mith.Kiss;
import java.awt.*;
import java.awt.image.*;
import java.io.*;


public class KissCell extends KissObject implements Cloneable {
  static final byte GSKISSCELL   = (byte)0x20;
  static final byte CKISSCELL     = (byte)0x21;

  private int x,y;

  private int offsetX;
  private int offsetY;
  
  private int width;
  private int height;

  private int widthMax;
  private int heightMax;
  int objectNumber;
  private int current;

  private Image image;
  int id;
  int fixed;
  boolean visible[] = new boolean [10];
  private  boolean v[] = new boolean [10];
  private byte pix[]; 
  private int  pix2[]; 

  String comment = "";

//  private ColorModel cm;
  private int basepix = 0;
  private int pixadd = 0;
  private MemoryImageSource mis;
  private int celmark;

  public synchronized Object clone() {
    try { 
      KissCell obj = (KissCell)super.clone();
      if(visible!=null) {
        obj.visible = new boolean[10];
        System.arraycopy(visible,0,obj.visible,0,visible.length);
      }
      if(v!=null) {
        obj.v = new boolean[10];
        System.arraycopy(v,0,obj.v,0,v.length);
      }
      if(pix!=null) {
        obj.pix  = new byte [pix.length];
        System.arraycopy(pix,0,obj.pix,0,pix.length);
      }
      if(pix2!=null) {
        obj.pix2  = new int [pix2.length];
        System.arraycopy(pix2,0,obj.pix2,0,pix2.length);
      }
      obj.image = null;
      obj.mis = null;
      return obj;
    } catch (CloneNotSupportedException e) { 
       throw new InternalError();
    }
  }

  public KissCell(String name){super(name,KissObject.CELL);}

  public void addCellInfomation(CellArray cell,KissPalette kp) {
    addCellInfomation(0 ,cell,kp) ;
  }

  public void addCellInfomation(int num ,CellArray cell,KissPalette kp) {
    objectNumber = num;
    id   = cell.id;
    basepix = kp.getPaletteBase(cell.base);
    fixed= cell.fixed;
    visible = cell.visible;
    for(int i=0;i<visible.length;i++)v[i]=visible[i];
    comment = cell.comment;
  }

  public void load(InputStream in) throws IOException{
    celLoad(in);
  }

  private void celLoad4(InputStream fin,int width,int height) throws IOException {
    int x,y,i,j;
    int size = (width + 1) / 2 * height;
    int offset = 0;

    byte pix[] = new byte [width * height];
    byte b[] = new byte [size];
    while(size > 0 ) {
      int r = fin.read(b,offset,size);
      size -= r;
      offset += r;
      if(r<0)break;
   }

    i=0;j=0;
    for(y=0;y<height;y++) {
      if((width & 0x01) == 0 ) {
        for(x=0;x<width;x+=2)  {
          int c = ((int)b[j++])&0xff;
          int c0 = (c>>4)&0x0f;
          int c1 = c&0x0f;
          pix[i++] = (byte)c0;
          pix[i++] = (byte)c1;
        }
      } else {
        for(x=0;x<width-1;x+=2)  {
          int c = ((int)b[j++])&0xff;
          int c0 = (c>>4)&0x0f;
          int c1 = c&0x0f;
          pix[i++] = (byte)c0;
          pix[i++] = (byte)c1;
        }
        int c = ((int)b[j++])&0xff;
        int c0 = (c>>4)&0x0f;
        pix[i++] = (byte)c0;
      }
    }
    this.width = width;
    this.height= height;
    this.pix= pix;
  }

  private void celLoad8 (InputStream fin,int width,int height) throws IOException {
    byte pix[] = new byte [width * height];
    int size = width * height;
    int offset = 0;
    while(size > 0 ) {
      int r = fin.read(pix,offset,size);
      size -= r;
      offset += r;
      if(r<0)break;
   }

    this.width = width;
    this.height= height;
    this.pix= pix;
  }

  private void celLoad32 (InputStream fin,int width,int height) throws IOException {
    byte b[] = new byte [width * height * 4];
    int  pix[] = new int [width * height];
    int size = width * height * 4;
    int offset = 0;
    while(size > 0 ) {
      int r = fin.read(b,offset,size);
      size -= r;
      offset += r;
      if(r<0)break;
    }

    for(int i=0,j=0;i<size;i+=4) {
      pix[j++] = 
        (b[i] & 0xff) +                  //b
        ((b[i+1]  << 8) & 0xff00) +      //g
        ((b[i+2]  << 16) & 0xff0000) +   //r
        (b[i+3]  << 24);                 //a
    }

    this.width = width;
    this.height= height;
    this.pix2 = pix;
  }

  private void celLoad(InputStream fin) throws IOException{
    byte b[] = new byte [32];
    fin.read(b,0,4);
    int x0 = (int)b[0] & 0xff;
    int x1 = (int)b[1] & 0xff;
    int width = x0 | (x1 << 8);
    int y0 = (int)b[2] & 0xff;
    int y1 = (int)b[3] & 0xff;
    int height = y0 | (y1 << 8);

    if(x0==0x4B && x1==0x69 && y0 == 0x53 && y1 == 0x53) {  //"KiSS"
      fin.read(b,4,32-4);

      celmark = (int)b[4] & 0xff;
      int ppb = (int)b[5] & 0xff;
//      int res = (int)b[6] & 0xff;
//      res = (int)b[7] & 0xff;
      x0 = (int)b[8] & 0xff;
      x1 = (int)b[9] & 0xff;
      width = x0 | (x1 << 8);
      y0 = (int)b[10] & 0xff;
      y1 = (int)b[11] & 0xff;
      height = y0 | (y1 << 8);

      x0 = (int)b[12] & 0xff;
      x1 = (int)b[13] & 0xff;
      this.offsetX = x0 | (x1 << 8);
      y0 = (int)b[14] & 0xff;
      y1 = (int)b[15] & 0xff;
      this.offsetY = y0 | (y1 << 8);

      if(b[4] == CKISSCELL) {
        celLoad32(fin,width,height);
      } else {
        switch(ppb) {
        case 4:
          celLoad4(fin,width,height);
        break;
        case 8:
          celLoad8(fin,width,height);
        break;
        }
      }
    } else {
      celLoad4(fin,width,height);
    }
    widthMax = width + offsetX;
    heightMax= height+ offsetY;
  }

  void setPos(int x,int y) {
    this.x = x + this.offsetX;
    this.y = y + this.offsetY;
  }

  boolean compareID(int id) {
    if(this.id == id)return true;
    return false;
  }

  int getID() {
    return id;
  }


  void getImage(IndexColorModel icm,Component ap) {
    int s = (256 - transparent) * 255 /256;
    ColorModel model;

    if(celmark == CKISSCELL) {
      model = ColorModel.getRGBdefault();
//      cm = model;

      if(image==null) {
        image= ap.createImage(mis = new MemoryImageSource(width, height,model, pix2, 0, width));
        mis.setAnimated(true);
      } else {
        mis.newPixels(pix2,model,0,width);
      }

    } else {
      if(basepix != pixadd) {
        int a = basepix - pixadd;
        for (int i=0;i<pix.length;i++) {
          int c  = ((int)pix[i]) & 0xff;
          pix[i] = (byte)((c==0)? 0 : c + a) ;
        }
        pixadd = basepix;
      }
      if(s!=255) {
        int t = icm.getMapSize();
        byte red[] = new byte [t];
        byte green[] = new byte [t];
        byte blue[] = new byte [t];
        byte alpha[] = new byte [t];
        icm.getReds(red);
        icm.getGreens(green);
        icm.getBlues(blue);
        for(int i=0;i<t;i++) {
          alpha[i] = (byte)(icm.getAlpha(i) * s / 255);
        }
        model = new IndexColorModel(8,t,red,green,blue,alpha);
      } else {
        model = icm;
      }
//      cm  = icm;
      if(image==null) {
        image= ap.createImage(mis = new MemoryImageSource(width, height,model, pix, 0, width));
        mis.setAnimated(true);
      } else {
        mis.newPixels(pix,model,0,width);
      }
    }
  }

  boolean addImage(Graphics grp,int p,ImageObserver ap ) {
     if(v[p] == true) {
       if(image == null)System.out.println("Image is null");
       grp.drawImage(image,x,y,ap);
       return true;
     }
     return false;
  }

  boolean addImage(Graphics grp,ImageObserver ap ) {
     return addImage(grp,current,ap);
  }

  void setVisible(boolean flag) {
    for(int i=0;i<visible.length;i++)
      if(visible[i])v[i] = flag;
  }

  void setVisible() {
    for(int i=0;i<visible.length;i++)
      if(visible[i])v[i] = !v[i];

  }

  boolean getVisible() {
    return v[current];
  }

  void setCurrent(int i) {
    current = i;
  }


  boolean isMoveImage(int x, int y) {
    return isMoveImage(x,y,current);
  }

  boolean isMoveImage(int x, int y,int patternSelect) {
    if(v[patternSelect] == false)return false;
    return isLocateImage(x,y,patternSelect);
  }

  boolean isLocateImage(int x, int y) {
    return isLocateImage(x,y,current);
  }

  boolean isLocateImage(int x, int y,int patternSelect) {
    if(this.x <= x && this.y <= y && (this.x + this.width -1) >= x && (this.y + this.height - 1) >= y ) {
      if( this.pix[(y - this.y) * this.width + (x - this.x)] != (byte)0) {
        return true;
      }
    }
    return false;
  }

  boolean getRectImage(int x, int y,int width,int height) {
    return getRectImage(x,y,width,height,current);
  }

  boolean getRectImage(int x, int y,int width,int height,int patternSelect) {
     if(v[patternSelect] == false)return false;
     if( (this.x <= x && x <= this.x + this.width) ||
         (this.x <= x + width && x + width <= this.x + this.width) || 
         (x  <= this.x && this.x <= x + width) ) {
       if( (this.y <= y && y <= this.y + this.height) ||
           (this.y <= y + height && y + height <= this.y + this.height) ||                 (y <= this.y && this.y <= y + height) ) {
         return true;
       }
    }
     return false;
  }

  int getX()  {
    return x;
  }
  int getY()  {
    return y;
  }

/*
  public Rectangle getClipSize()  {
     int x = Math.min(px,this.x) ;
     int y = Math.min(py,this.y) ;
     int w  = this.width + Math.max(px,this.x) ;
     int h  = this.height + Math.max(py,this.y) ;
     return new Rectangle(x,y,w,h);
  }
*/

  boolean checkFixed() {
    if(fixed == 0) return false;
    return true;
  }

  int decFixed() {
    fixed --;
    if(fixed < 0)fixed = 0;
    return fixed;
  }

  Dimension getSize() {
    return new Dimension(width+offsetX,height+offsetY);
  }

  void setMaxSize(int width,int height) {
    widthMax = width;
    heightMax= height;
  }

  Dimension getMaxSize() {
	    return new Dimension(widthMax,heightMax);
  }

  Rectangle getBounds() {
    return new Rectangle(x,y,width,height);
  }

  int transparent = 0;

  synchronized void setTransparentOrder(int num) {
    transparent = num;
    if(transparent>256)transparent=256;
    if(transparent<0)transparent=0;
  }

  synchronized void addTransparentOrder(int num) {
    transparent+= num;
    if(transparent>256)transparent=256;
    if(transparent<0)transparent=0;
  }
  synchronized int getTransparentOrder(int num) {
    return transparent;
  }

}

