package jp.gr.java_conf.mith.Kiss;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;


public class KissManager {
  int width,pwidth;
  int height,pheight;
  int dragX,dragY,cx,cy;
  int objectNumber;
  int backgroundPalette;
  int paletteSelect;
  int dragObject;
  KissCell cells[];
  KissPalette kissPal;
  IndexColorModel icm;
  int patternSelect;
  Image imgPanel,imgBuffer;
  KissConfig cnf;
  private Color bgColor;
  private Color frmColor;
  Hashtable<String, KissObject> cnfHash,celHash,palHash;
  Component component;
  Rectangle ra = null;
  boolean loaded;
  Vector<KissCell> listID;
  boolean update_flag = true;

  
  CellObject cobj[];

  public KissManager(Component c) {
	component = c;
    init();
  }

  public KissManager() {
    component = null;
    init();
  }

  public boolean getLoaded() {
    return loaded;
  }

  public synchronized void setComponent(Component c) {
    component = c;
    if(c==null)return ;
    if(loaded){
      produceImage(patternSelect);
      initialize (patternSelect);
      component.repaint();
      begin ();
    }
  }

  public synchronized Component getComponent() {
    return component;
  }

  public synchronized void init() {
     width  = 448;  // 320
     height = 320;  // 200
     objectNumber = 0;
     backgroundPalette = 0;
     paletteSelect = -1;
     dragObject = -1;
     cells = null;
     kissPal = null;
     icm = null;
     patternSelect = 0;
     cnf = null;
     bgColor = null;
     frmColor = null;
     cnfHash = new Hashtable<String, KissObject>();
     celHash = new Hashtable<String, KissObject>();
     palHash = new Hashtable<String, KissObject>();
     cx=0;cy=0;dragX=0;dragY=0;
     loaded = false;
     listID = null;
     update_flag = true;
     imgPanel = null;
     imgBuffer = null;
  }

  public synchronized void loadFromZip(ZipInputStream zi) throws IOException {
    loadFromZip(zi,"SJIS");
  }
  public synchronized void loadFromZip(ZipInputStream zi,String code) throws IOException {
    ZipEntry entry;

    while((entry = zi.getNextEntry()) != null) {
      String fname = entry.getName().toLowerCase();
      String ex = fname.substring(fname.length()-4);
      if(ex.equals(".cel")) {
        KissCell cell = new KissCell(fname);
        cell.load(zi);
        addObject(cell);
      } else if(ex.equals(".kcf")) {
        KissPalette pal = new KissPalette(fname);
        pal.load(zi);
        addObject(pal);
      } else if(ex.equals(".cnf") || ex.equals(".cfg")) {
        KissConfig cnf = new KissConfig(fname);
        cnf.load(zi,"SJIS");
        addObject(cnf);
      } else if(ex.equals(".wav") || ex.equals(".pcm")) {
    	  //
      }
      zi.closeEntry();
    }
  }

  public Color getFormColor() {
    return frmColor;
  }

  public Color getBackColor() {
    return bgColor;
  }

  public synchronized boolean setConfig(String name) {
    return setConfig(name,0);
  }

  public synchronized boolean setConfig(String name,int patternSelect) {
    KissConfig c = (KissConfig)cnfHash.get(name.toLowerCase());
    if(c == null)return false;
    return setConfig(c,patternSelect);
  }

  public synchronized boolean setConfig(KissConfig c) {
    return setConfig(c,0);
  }

  synchronized boolean initConfig(KissConfig c,int patternSelect) {
    this.patternSelect = patternSelect;
    try {
      cnf = c;
      kissPal = new KissPalette(c.name+".pal");
      for(int i=0;i<cnf.palmax;i++) {
        kissPal.append((KissPalette)palHash.get(cnf.paletteFile[i].toLowerCase()));
      }
      cells = new KissCell[cnf.celmax];
      for(int i=0;i<cnf.celmax;i++) {
        KissCell cell = (KissCell)celHash.get(cnf.cells[i].filename.toLowerCase());
        cells[i] = (KissCell) cell.clone();
        cells[i].addCellInfomation(i,cnf.cells[i],kissPal);
      }

      int posmax = 0;

      for(int i=0;i<cnf.celmax;i++) {
        int posnum = cells[i].getID();
        if(posnum>posmax)posmax = posnum;
      }
      posmax ++;

      cobj = new CellObject [posmax];
      for(int i=0;i<posmax;i++) {
        listID = new Vector<KissCell>();
        for(int j = 0 ; j< cnf.celmax ; j++ ) {
          if(cells[j].compareID(i) == true) {
            listID.addElement(cells[j]);
          }
        }
        cobj[i] = new CellObject (listID);
      }
      

      for(int i=0;i<cnf.patternNum;i++) {
        setLocation(i);
      }
      width = cnf.width;
      height= cnf.height;
    } catch (NullPointerException e) {
      System.err.println(e);
      return false;
    }
    return true;
  }

  public synchronized KissConfig getConfig() {
    return cnf;
  }

  public synchronized Dimension getSize() {
    if(cnf!=null) {
      return new Dimension(cnf.width,cnf.height);
    } else {
      return new Dimension(width,height);
    }
  }

  public synchronized boolean setConfig(KissConfig c,int patternSelect) {
    boolean flag = initConfig(c,patternSelect);
    if(flag) {
      if(component!=null) { 
        loaded = true;
        produceImage(patternSelect);
        initialize (patternSelect);
        component.repaint();
        begin ();
      } else {
        loaded = true;
      }
    }
    return loaded;
  }

  public synchronized void addObject(String name,InputStream in,int type) throws IOException {
    KissObject obj;
    switch(type) {
      case KissObject.CONFIG:
        obj = new KissConfig(name);
        obj.load(in);
        cnfHash.put(name.toLowerCase(),obj);
      break;
      case KissObject.PALETTE:
        obj = new KissPalette(name);
        obj.load(in);
        palHash.put(name.toLowerCase(),obj);
      break;
      case KissObject.CELL:
        obj = new KissCell(name);
        obj.load(in);
        celHash.put(name.toLowerCase(),obj);
      break;
      default:
        return ;
    }
  }


  public synchronized void addObject(KissObject obj) {
    switch(obj.type) {
      case KissObject.CONFIG:
        cnfHash.put(obj.name.toLowerCase(),obj);
      break;
      case KissObject.PALETTE:
        palHash.put(obj.name.toLowerCase(),obj);
      break;
      case KissObject.CELL:
        celHash.put(obj.name.toLowerCase(),obj);
      break;
    }
  }

  private void setLocation(int u) {
    CellLocation l = cnf.location[u];
    for(int i=0;i<cobj.length;i++) {
      Point p = l.getPos(i);
      if(p!=null)cobj[i].setDefaultPos(p.x,p.y,u);
      else       cobj[i].setDefaultPos(0,0,u);
    }
  }

  public synchronized void initialize (int num) {
  }

  public synchronized void begin () {
  }

  public synchronized void terminate () {
    loaded = false;
  }


  public synchronized int getSelectedPattern () {
    return patternSelect;
  }

  public synchronized int getSelectedPalette () {
    return paletteSelect;
  }

  public synchronized void reproduceImage (int num) {
    produceImage(num);
    component.repaint();
  }

  public synchronized void producePalette (int num) {
    paletteSelect = num;
    icm = kissPal.getSelectedPalette(paletteSelect);

    for(int t=0;t < cnf.celmax ;t++) {
      cells[t].getImage(icm,component);
    }

    bgColor  = kissPal.getSelectedColor(0);
    frmColor = kissPal.getSelectedColor(cnf.backgroundPalette);
    ra = new Rectangle (0,0,cnf.width,cnf.height);
  }

  synchronized void reproducePalette (int num) {
    producePalette(num);
    component.repaint();
  }

  
  public synchronized int getSelectPattern() {
    return patternSelect;
  }

  public synchronized int getSelectPalette() {
    return paletteSelect;
  }

  public synchronized void setSelectPattern(int num) {
    reproduceImage (num);
  }

  public synchronized void setSelectPalette(int num) {
    reproducePalette (num);
  }

  synchronized void produceImage (int num) {
    patternSelect = num;
    if(cnf.patternNum<=patternSelect)patternSelect =0;
    for(int i=0;i<cobj.length;i++) {
      if(cobj[i]!=null) {
        cobj[i].setCurrent(patternSelect);
      }
    }

    if( paletteSelect != cnf.getPaletteNumber(num)) {
      paletteSelect = cnf.getPaletteNumber(num);
      icm = kissPal.getSelectedPalette(paletteSelect);
      for(int t=0;t < cnf.celmax ;t++) {
        cells[t].getImage(icm,component);
      }
    }

    bgColor  = kissPal.getSelectedColor(0);
    frmColor = kissPal.getSelectedColor(cnf.backgroundPalette);

    ra = new Rectangle (0,0,cnf.width,cnf.height);
  }

  private void putonImage(int ClipX,int ClipY,int ClipWidth,int ClipHeight) {
    if(component == null)return ;
    if(imgPanel==null) {
      imgPanel = component.createImage(cnf.width,cnf.height);
      if(imgPanel==null) return ;
    }
    Graphics grp = imgPanel.getGraphics();
    grp.setColor(bgColor);
    grp.clipRect(ClipX,ClipY,ClipWidth,ClipHeight);
    grp.fillRect(ClipX,ClipY,ClipWidth,ClipHeight);
    for(int i=cnf.celmax;i>0;) {
      i--;
      if(cells[i].getRectImage(ClipX,ClipY,ClipWidth,ClipHeight,patternSelect)) {
               cells[i].addImage(grp,patternSelect,component);
      }
    }
  }

  private void putonImage() {
    putonImage(0,0,cnf.width,cnf.height);
  }


  public void update () {
    update_flag = true;
  }

  public void paint (Graphics g) {
    try {
      if(loaded == false)return;
      Dimension d = component.getSize();
      int sx = (d.width - cnf.width +1) /2;
      int sy = (d.height- cnf.height+1) /2;

      if(pwidth != d.width || pheight != d.height)update_flag = true;

      if(ra!=null && !update_flag) {
        g.clipRect(ra.x + sx ,ra.y + sy,ra.width,ra.height);
        putonImage(ra.x,ra.y,ra.width,ra.height);
        if(imgPanel!=null)g.drawImage(imgPanel,sx,sy,component);
      } else {
        if(update_flag || imgBuffer==null) {
          imgBuffer = component.createImage(d.width,d.height);
          pwidth = d.width;
          pheight= d.height;
        }
        update_flag = false;
        Graphics gg = imgBuffer.getGraphics();
        gg.setColor(frmColor);
        gg.fillRect(0,0,d.width,d.height);
        putonImage();
        if(imgPanel!=null)gg.drawImage(imgPanel,sx,sy,component);
        g.drawImage(imgBuffer,0,0,component);
      }
      ra = null;
    }catch (Exception e){}
  }


  synchronized void executeClipRect(int id,int dx,int dy) {
    cobj[id].addPos(dx,dy,cnf.width,cnf.height);
    executeClipRect(id);
  }

  synchronized final void executeClipRect(int id) {
    Rectangle rr = ra;
    Rectangle r = cobj[id].getClipSize();

    if(rr == null) {
      ra = r;
    } else {
      rr.x = Math.min(rr.x,r.x);
      rr.y = Math.min(rr.y,r.y);
      int w = Math.max(rr.x + rr.width,r.x + r.width);
      int h = Math.max(rr.y + rr.height,r.y + r.height);
      rr.width  = w - rr.x;
      rr.height = h - rr.y;
      ra = rr;
    }
  }

  synchronized final void executeClipRect(KissCell cell) {
    Rectangle rr = ra;
    Rectangle r = cell.getBounds();
    if(rr == null) {
      ra = r;
    } else {
      rr.x = Math.min(rr.x,r.x);
      rr.y = Math.min(rr.y,r.y);
      int w = Math.max(rr.x + rr.width,r.x + r.width);
      int h = Math.max(rr.y + rr.height,r.y + r.height);
      rr.width  = w - rr.x;
      rr.height = h - rr.y;
      ra = rr;
    }
  }

  void pressEvent(int id,int x,int y) {
  }

  int checkPressObject(int x,int y) {
    for(int i=0;i < cnf.celmax ; i++) {
      if(cells[i].isMoveImage(x,y,patternSelect)) {
        return cells[i].getID();
      }
    }
    return -1;
  }


  void unfixedEvent(int id,int x,int y) {
  }

  void fixedCatchEvent(int id,int x,int y) {
  }

  void catchEvent(int id,int x,int y) {
  }

  void defaultCatchEvent(int id,int x,int y) {
    catchEvent(id,x,y);

    if(cobj[id].isFix()) {
      fixedCatchEvent(id,x,y);
    }
  }

  int ox,oy,pesiCount;

  public synchronized void press(int x,int y) { 
    if(loaded == false)return ;
    Dimension d = component.getSize();
    x -= (d.width - cnf.width +1) /2;
    y -= (d.height- cnf.height+1) /2;
    int id = checkPressObject(x,y);
    if(id == -1)return ;
    ox = cobj[id].x;oy = cobj[id].y;
    cx=x; cy=y;
    dragX=x; dragY=y;
    pesiCount = 0;
    pressEvent(id,x,y);
    defaultCatchEvent(id,x,y);
    dragObject = id;
  }

  private boolean pesiPesi(int x,int y) {
    int id = dragObject;
    CellObject p = cobj[id]; 
    if (p.isFix()) {
      int pesiLimit = p.getPesiLimit();
      int moveLimit = p.getMoveLimit(pesiLimit);
      pesiCount++;

      if (x < cx - moveLimit) {
        x = cx - moveLimit;
        pesiCount = pesiLimit;
      }
      if (x > cx + moveLimit) {
        x = cx + moveLimit;
        pesiCount = pesiLimit;
      }
      if (y < cy - moveLimit) {
        y = cy - moveLimit;
        pesiCount = pesiLimit;
      }
      if (y > cy + moveLimit) {
        y= cy + moveLimit;
        pesiCount = pesiLimit;
      }

      if (pesiCount >= pesiLimit) {
        pesiCount = pesiLimit;
        p.subFix(pesiCount);
        pesiCount = 0;
        if (p.isFix()) {
          p.setPos(ox,oy);
          fixedDropEvent(id,cx,cy);
          dropEvent(id,cx,cy);
          dragObject = -1;
          ra = new Rectangle(0, 0,cnf.width,cnf.height);
          return true;
        } else {
          unfixedEvent(id,x,y);
        }
      }
    }
    executeClipRect(dragObject,x-dragX,y-dragY);
    dragX = x;dragY =y;
    return false;
  }


  void releaseEvent(int x,int y){}
  void dropEvent(int id,int x,int y){}
  void fixedDropEvent(int id,int x,int y){}

  public synchronized void release(int x,int y) {
    if(loaded == false) return ;
    Dimension d = component.getSize();
    x -= (d.width - cnf.width +1) /2;
    y -= (d.height- cnf.height+1) /2;
    releaseEvent(x,y);
    if(dragObject==-1) return;
    int id = dragObject;

    if(cobj[id].isFix()) {
      fixedDropEvent(id,x,y);
    }
    dropEvent(id,x,y);
    dragObject = -1;
    ra = new Rectangle(0, 0,cnf.width,cnf.height);
    component.repaint();
  }

  public synchronized void drag(int x,int y) {
    if(dragObject==-1 || loaded == false)return;

    Dimension d = component.getSize();
    x -= (d.width - cnf.width +1) /2;
    y -= (d.height- cnf.height+1) /2;

    pesiPesi(x,y);
    component.repaint();
  }

  public synchronized void moved(int x,int y) {
    String str;
    str = "X:" + x + "Y:" + y;
    putStatus(str); 
  }

  public void putStatus(String str) {
/*
    kissMessanger.showKissStatus(str);
*/
  }

  public String[] getCommentForXY(int x,int y) { 
    if(loaded == false)return null;
    Dimension d = component.getSize();
    x -= (d.width - cnf.width +1) /2;
    y -= (d.height- cnf.height+1) /2;
    for(int i=0;i < cnf.celmax ; i++) {
      if(cells[i].isMoveImage(x,y,patternSelect)) {
        return getCommentForID(cells[i].getID());
      }
    }
    return null;
  }

  public String[] getCommentForID(int id) {
    return cobj[id].comment;
  }

  public void getSetEnable (boolean b[]) {
    int x = 10;
    if(b.length<10)x = b.length;
    for(int i=0;i<x;i++)b[i]=false;
    if(cnf==null)return;
    for(int i=0;i<x;i++) {
      if(cnf.location[i]!=null)
        if(cnf.location[i].posmax>1)b[i]=true;
    }
  }

  public void getColEnable (boolean b[]) {
    int t = 10;
    if(b.length<10)t = b.length;
    for(int i=0;i<t;i++)b[i]=false;
    if(cnf==null)return;
    int u = kissPal.getMaxColorSet();
    if(t<u)u = t;
    for(int i=0;i<u;i++) {
      b[i]=true;
    }
  }

}
