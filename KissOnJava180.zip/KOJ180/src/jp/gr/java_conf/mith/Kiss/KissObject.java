package jp.gr.java_conf.mith.Kiss;
import java.io.*;

public class KissObject extends Object {
  public static final int UNKNOWN =-1;
  public static final int CONFIG  = 0;
  public static final int CELL    = 1;
  public static final int PALETTE = 2;

  int    type = UNKNOWN;
  String name,err = "";
  boolean loaded =false;

  public int getType() {
    return type;
  }

  public KissObject(String name,int type) {
    this.name = name;
    this.type = type;
  }

  public void load(InputStream in) throws IOException {
  
  }

  public String getErrorMessage() {
    return err;
  }
}
