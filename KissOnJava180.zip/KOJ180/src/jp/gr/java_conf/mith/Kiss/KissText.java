package jp.gr.java_conf.mith.Kiss;
import java.io.*;
import java.util.*;

public class KissText extends Object {
  public static final int UNKNOWN =-1;
  public static final int CONFIG  = 0;
  public static final int CELL    = 1;
  public static final int PALETTE = 2;
  public static final int TEXT    = 3;

  int    type = UNKNOWN;
  String name,err = "";
  boolean loaded =false;
  String text[];

  public boolean getLoaded() {
    return loaded;
  }

  public int getType() {
    return type;
  }

  public KissText(String name,int type) {
    this.name = name;
    this.type = type;
  }

  public void load(InputStream in) throws IOException {
    load(in,"SJIS");
  }

  public void load(InputStream in,String code) throws IOException {
    BufferedReader din = new BufferedReader(new InputStreamReader(in,code));
    Vector<String> v = new Vector<String>();
    while(true) {
      String l = din.readLine();
      if(l==null)break;
      v.addElement(l);
    }
    text = new String[v.size()];
    for(int i=0;i<v.size();i++) {
      text[i] = v.elementAt(i);
    }
  }

  public String[]  getText(){
    return text;
  }

  public String getErrorMessage() {
    return err;
  }
}
