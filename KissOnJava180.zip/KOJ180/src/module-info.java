/**
 * 
 */
/**
 * @author misir
 *
 */
module JKISS {
	exports jp.gr.java_conf.mith.Kiss;
	requires transitive java.desktop;
}